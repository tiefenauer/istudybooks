<?php
  include 'view_fixt.php';
  $this->load->viewfile(TESTSPATH . 'fixtures/view_fixt.php', $data);
?>
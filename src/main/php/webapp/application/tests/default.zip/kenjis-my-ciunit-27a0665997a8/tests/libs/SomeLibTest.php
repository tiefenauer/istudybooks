<?php

/**
 * @group Lib
 */

class SomeLibTest extends CIUnit_TestCase
{
	public function setUp()
	{
		// Set up fixtures to be run before each test
		
		// Load the tested library so it will be available in all tests
		//$this->CI->load->library('example_lib', '', mylib);
	}
	
	public function testMethod()
	{
		// Check if everything is ok
		//$this->assertEquals(4, $this->CI->mylib->add(2, 2));
	}
}

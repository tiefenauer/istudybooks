<?php

/**
 * @group Helper
 */

class HelperTest extends CIUnit_TestCase
{
	public function setUp()
	{
		//$this->CI->load->helper('example');
	}
	
	public function testSampleFunction()
	{
		//$this->assertEquals('Hi!', say('Hi!'));
	}
}
